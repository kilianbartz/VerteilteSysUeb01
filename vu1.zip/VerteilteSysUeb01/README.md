---

Kilian Bartz (1538561)
Dieses Repo enthält meine Abgabe zu Übung 1, Verteilte Systeme, Sommer 2024. Enthalten sind die

- Programme zu Aufgabe 1, 2a, 2b und 2c,
- die CSV Dateien zu Aufgabe 1
- die Notebooks, die verwendet wurden, um die Ergebnisse zu plotten.
